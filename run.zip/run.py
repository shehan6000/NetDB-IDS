#!/usr/bin/env python3
"""
NetDB-IDS · Fully Automated Demo + Test Suite
==============================================
One command runs everything end-to-end:

    python run.py demo

What it does:
  1.  Installs all Python dependencies
  2.  Cleans stale data from previous runs
  3.  Starts Mock DB Server  (port 5433)
  4.  Starts ML Correlator
  5.  Starts Streamlit Dashboard (port 8501)
  6.  Health-checks every service
  7.  Generates fast baseline traffic  → trains Isolation Forest
  8.  Runs 4 attack scenarios in order
  9.  Waits for ML scoring to complete
  10. Runs 10 automated tests
  11. Prints P/R/F1 benchmark report
  12. Opens browser to dashboard
  13. Keeps running until Ctrl+C

Other commands:
    python run.py test    # tests only (services must be running)
    python run.py start   # services only, no attacks
    python run.py attack  # attacks only
    python run.py eval    # benchmark report only
    python run.py clean   # stop + wipe data
"""

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

VENDOR_DIR = Path(__file__).parent.resolve() / "vendor"
if VENDOR_DIR.exists():
    sys.path.insert(0, str(VENDOR_DIR))

# Import duckdb at module level
import duckdb

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

BASE_DIR   = Path(__file__).parent.resolve()
DATA_DIR   = BASE_DIR / "data"
PROXY_PORT = 5433
DASH_PORT  = 8501
DEFAULT_BASELINE_COUNT = int(os.getenv("NETDB_BASELINE_COUNT", "60"))

PACKAGES = [
    "duckdb", "sqlglot", "scikit-learn", "numpy",
    "streamlit", "pandas", "plotly", "structlog", "joblib",
]
IMPORT_CHECKS = {
    "duckdb": "duckdb",
    "sqlglot": "sqlglot",
    "scikit-learn": "sklearn",
    "numpy": "numpy",
    "streamlit": "streamlit",
    "pandas": "pandas",
    "plotly": "plotly",
    "structlog": "structlog",
    "joblib": "joblib",
}

# ── Colors ─────────────────────────────────────────────────────────────────
R  = "\033[91m"
G  = "\033[92m"
Y  = "\033[93m"
C  = "\033[96m"
DIM= "\033[2m"
B  = "\033[1m"
X  = "\033[0m"

processes: list = []

# ══════════════════════════════════════════════════════════════════════════
# PRINT HELPERS
# ══════════════════════════════════════════════════════════════════════════

def header(title: str, color: str = C):
    w = 64
    print(f"\n{color}{B}{'═'*w}\n  {title}\n{'═'*w}{X}\n")

def section(title: str):
    pad = 56 - len(title)
    print(f"\n{Y}{B}── {title} {'─'*max(pad,2)}{X}")

def step(msg: str):  print(f"{C}  ▶{X} {msg}")
def ok(msg: str):    print(f"{G}    ✓{X} {msg}")
def fail(msg: str):  print(f"{R}    ✗{X} {msg}")
def warn(msg: str):  print(f"{Y}    ⚠{X} {msg}")
def info(msg: str):  print(f"{DIM}      {msg}{X}")


# ══════════════════════════════════════════════════════════════════════════
# SETUP & PROCESS MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════

def pip_install():
    missing = []
    for package, module in IMPORT_CHECKS.items():
        try:
            __import__(module)
        except Exception:
            missing.append(package)
    if not missing:
        ok("Python dependencies already installed")
        return

    step("Installing Python dependencies...")
    r = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet"] + missing,
        capture_output=True, text=True,
    )
    if r.returncode == 0:
        ok(f"Installed: {', '.join(missing)}")
    else:
        fail("pip install failed")
        print(r.stderr[:500])
        sys.exit(1)


def clean_data():
    step("Clearing old data...")
    if DATA_DIR.exists():
        shutil.rmtree(DATA_DIR)
    DATA_DIR.mkdir(exist_ok=True)
    ok("data/ directory cleared")


def port_open(port: int, host: str = "127.0.0.1", timeout: float = 1.0) -> bool:
    try:
        s = socket.socket()
        s.settimeout(timeout)
        s.connect((host, port))
        s.close()
        return True
    except Exception:
        return False


def wait_for_port(port: int, timeout: int = 30) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if port_open(port):
            return True
        time.sleep(0.2)
    return False


def launch(name: str, *cmd_args):
    cmd = [sys.executable] + list(cmd_args)
    env = os.environ.copy()
    env["PYTHONPATH"] = str(VENDOR_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    p = subprocess.Popen(
        cmd,
        cwd=str(BASE_DIR),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    processes.append((name, p))
    return p


def stop_all():
    print(f"\n{Y}Stopping all services...{X}")
    for name, p in processes:
        try:
            p.terminate()
            p.wait(timeout=4)
            ok(f"Stopped {name}")
        except Exception:
            pass


def start_services():
    section("STARTING SERVICES")

    step("Mock DB Server (port 5433)...")
    launch("Mock DB", str(BASE_DIR / "proxy" / "mock_db_server.py"))
    if wait_for_port(PROXY_PORT, timeout=20):
        ok("Mock DB Server ready  →  127.0.0.1:5433")
    else:
        fail("Mock DB Server did not start — check proxy/mock_db_server.py")
        stop_all(); sys.exit(1)

    step("ML Correlator...")
    launch("Correlator", str(BASE_DIR / "correlator" / "correlator_native.py"))
    time.sleep(0.5)
    ok("ML Correlator started")

    step("Streamlit Dashboard (port 8501)...")
    launch(
        "Dashboard",
        "-m", "streamlit", "run",
        str(BASE_DIR / "dashboard" / "dashboard.py"),
        "--server.port=8501",
        "--server.headless=true",
        "--global.developmentMode=false",
        "--logger.level=error",
    )
    if wait_for_port(DASH_PORT, timeout=25):
        ok("Dashboard ready  →  http://localhost:8501")
    else:
        if processes[-1][1].poll() is not None:
            out = processes[-1][1].stdout.read().decode("utf-8", errors="replace") if processes[-1][1].stdout else ""
            fail("Dashboard process exited")
            print(out[-1200:])
        else:
            warn("Dashboard still loading (will be ready shortly)")


def wait_for_scoring(timeout: int = 60):
    deadline = time.time() + timeout
    evt_file = DATA_DIR / "events.jsonl"
    corr_db = DATA_DIR / "correlator.db"
    last = (0, 0)
    while time.time() < deadline:
        try:
            event_count = sum(1 for _ in open(evt_file, encoding="utf-8")) if evt_file.exists() else 0
            scored = 0
            threat_classes = set()
            if corr_db.exists():
                result = read_duckdb_with_retry(str(corr_db), "SELECT COUNT(*) FROM scored_events", max_retries=2, delay=0.2)
                scored = result[0][0] if result else 0
                alerts = read_duckdb_with_retry(
                    str(corr_db),
                    "SELECT DISTINCT threat_class FROM alerts WHERE threat_class IS NOT NULL",
                    max_retries=2,
                    delay=0.2,
                )
                threat_classes = {row[0] for row in alerts or []}
            last = (event_count, scored)
            required = {"sqli", "privesc", "exfiltration"}
            if required.issubset(threat_classes):
                ok(f"Pipeline processing complete ({scored}/{event_count} events scored, required alerts ready)")
                return
            if event_count > 0 and scored >= max(0, event_count - 3):
                ok(f"Pipeline processing complete ({scored}/{event_count} events scored)")
                return
        except Exception:
            pass
        time.sleep(0.25)
    warn(f"Pipeline still catching up ({last[1]}/{last[0]} events scored)")


def run_scenario(scenario: str, *extra_args: str):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(VENDOR_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    r = subprocess.run(
        [sys.executable,
         str(BASE_DIR / "attack_sim" / "attack_sim_native.py"),
         "--scenario", scenario,
         *extra_args],
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        fail(f"Scenario '{scenario}' failed")
        print(r.stdout[-1200:])
        print(r.stderr[-1200:])
        raise RuntimeError(f"attack scenario failed: {scenario}")


# ══════════════════════════════════════════════════════════════════════════
# SQL HELPER
# ══════════════════════════════════════════════════════════════════════════

def db_query(sql: str, timeout: float = 5.0) -> str:
    try:
        s = socket.socket()
        s.settimeout(timeout)
        s.connect(("127.0.0.1", PROXY_PORT))
        s.recv(64)                        # READY
        s.sendall((sql + "\n").encode())
        resp = b""
        while b"END" not in resp:
            chunk = s.recv(8192)
            if not chunk:
                break
            resp += chunk
        s.close()
        return resp.decode("utf-8", errors="replace").replace("END", "").strip()
    except Exception as e:
        return f"ERROR: {e}"


# ══════════════════════════════════════════════════════════════════════════
# AUTOMATED TEST SUITE
# ══════════════════════════════════════════════════════════════════════════

def read_duckdb_with_retry(db_path, query, fetch_all=True, max_retries=5, delay=0.5):
    """Read from DuckDB with retry on Windows file locks."""
    for attempt in range(max_retries):
        try:
            conn = duckdb.connect(db_path, read_only=True)
            if fetch_all:
                result = conn.execute(query).fetchall()
            else:
                result = conn.execute(query)
            conn.close()
            return result
        except Exception as e:
            if attempt < max_retries - 1 and ("already open" in str(e) or "locked" in str(e)):
                time.sleep(delay)
                continue
            raise e
    return None

def read_df_with_retry(db_path, query, max_retries=5, delay=0.5):
    """Read DataFrame from DuckDB with retry logic."""
    for attempt in range(max_retries):
        try:
            conn = duckdb.connect(db_path, read_only=True)
            df = conn.execute(query).df()
            conn.close()
            return df
        except Exception as e:
            if attempt < max_retries - 1 and ("already open" in str(e) or "locked" in str(e)):
                time.sleep(delay)
                continue
            raise e
    return None

class TR:
    def __init__(self):
        self.passed:   list[str] = []
        self.failed:   list[str] = []
        self.warnings: list[str] = []

    def check(self, name: str, passed: bool, detail: str = ""):
        tag = f"  [{detail}]" if detail else ""
        if passed:
            self.passed.append(name); ok(f"{name}{tag}")
        else:
            self.failed.append(name); fail(f"{name}{tag}")
        return passed

    def advisory(self, msg: str):
        self.warnings.append(msg); warn(msg)

    def summary(self) -> bool:
        total = len(self.passed) + len(self.failed)
        section("TEST SUMMARY")
        print(f"  Passed  : {G}{B}{len(self.passed)}/{total}{X}")
        if self.failed:
            print(f"  Failed  : {R}{B}{len(self.failed)}{X}")
            for f in self.failed:
                print(f"    {R}✗  {f}{X}")
        for w in self.warnings:
            print(f"    {Y}⚠  {w}{X}")
        print()
        return len(self.failed) == 0


def run_tests() -> TR:
    tr       = TR()
    proxy_db = DATA_DIR / "proxy.db"
    corr_db  = DATA_DIR / "correlator.db"
    evt_file = DATA_DIR / "events.jsonl"
    net_file = DATA_DIR / "net_events.jsonl"

    # ── TEST 1: TCP connectivity ───────────────────────────────────────────
    section("TEST 1 · DB Server Connectivity")
    try:
        s = socket.socket()
        s.settimeout(3)
        s.connect(("127.0.0.1", PROXY_PORT))
        banner = s.recv(10)
        s.close()
        tr.check("TCP connect to port 5433",
                 b"READY" in banner, f"server replied: {banner!r}")
    except Exception as e:
        tr.check("TCP connect to port 5433", False, str(e))

    # ── TEST 2: SQL round-trip ────────────────────────────────────────────
    section("TEST 2 · SQL Execution (3 queries)")
    for sql, label in [
        ("SELECT * FROM users LIMIT 1",    "users table readable"),
        ("SELECT * FROM products LIMIT 1", "products table readable"),
        ("SELECT COUNT(*) FROM orders",    "orders table readable"),
    ]:
        resp = db_query(sql)
        passed = "ERROR" not in resp and len(resp.strip()) > 0
        tr.check(label, passed,
                 resp[:70].replace("\n", " ") if passed else resp[:80])

    # ── TEST 3: Feature extraction ────────────────────────────────────────
    section("TEST 3 · AST Feature Extraction (proxy.db)")
    tr.check("proxy.db created", proxy_db.exists())
    if proxy_db.exists():
        try:
            result = read_duckdb_with_retry(str(proxy_db), "SELECT COUNT(*) FROM db_events")
            if result is not None:
                total = result[0][0]
                tr.check("db_events populated", total > 0, f"{total} events logged")
            else:
                tr.check("db_events populated", False, "File locked after retries")
        except Exception as e:
            tr.check("db_events populated", False, str(e))

    # ── TEST 4: Schema integrity ──────────────────────────────────────────
    section("TEST 4 · DuckDB Schema Integrity")
    if proxy_db.exists():
        try:
            result = read_duckdb_with_retry(str(proxy_db), """
                SELECT column_name FROM information_schema.columns
                WHERE table_name = 'db_events'
            """, fetch_all=True)
            if result is not None:
                cols = {r[0] for r in result}
                required = {
                    "id", "timestamp", "client_ip", "raw_sql",
                    "heuristic_score", "has_union", "sensitive_tables",
                    "has_privilege_op", "sqli_pattern_count",
                    "has_wildcard", "has_drop", "has_comment",
                }
                missing = required - cols
                tr.check("db_events has all required columns",
                         len(missing) == 0,
                         f"missing: {missing}" if missing else f"{len(cols)} cols ✓")
            else:
                tr.check("Schema check", False, "File locked after retries")
        except Exception as e:
            tr.check("Schema check", False, str(e))

    # ── TEST 5: Heuristic scoring ─────────────────────────────────────────
    section("TEST 5 · Heuristic Scoring (attacks scored higher than baseline)")
    if proxy_db.exists():
        try:
            result = read_duckdb_with_retry(str(proxy_db), """
                SELECT AVG(heuristic_score), MAX(heuristic_score), COUNT(*)
                FROM db_events WHERE heuristic_score > 0
            """, fetch_all=True)
            if result is not None:
                avg, mx, cnt = (result[0][0] or 0), (result[0][1] or 0), (result[0][2] or 0)
                tr.check("Attack queries scored above 0",
                         cnt > 0, f"{cnt} flagged events, avg={avg:.2f}, max={mx:.2f}")
                tr.check("Max heuristic score >= 0.5",
                         mx >= 0.5, f"max_score={mx:.2f}")
            else:
                tr.check("Heuristic scoring", False, "File locked after retries")
        except Exception as e:
            tr.check("Heuristic scoring", False, str(e))

    # ── TEST 6: Event queue ───────────────────────────────────────────────
    section("TEST 6 · Cross-Process Event Queue (events.jsonl)")
    tr.check("events.jsonl created", evt_file.exists())
    if evt_file.exists():
        try:
            with open(evt_file) as f:
                lines = f.readlines()
            valid = sum(
                1 for l in lines[:30]
                if "raw_sql" in l and "heuristic_score" in l
            )
            tr.check("Event JSON lines valid",
                     valid > 0,
                     f"{len(lines)} total, {valid}/30 sampled valid")
        except Exception as e:
            tr.check("Event queue readable", False, str(e))

    section("TEST 6B · Network Telemetry Queue (net_events.jsonl)")
    tr.check("net_events.jsonl created", net_file.exists())
    if net_file.exists():
        try:
            with open(net_file, encoding="utf-8") as f:
                net_lines = [json.loads(line) for line in f if line.strip()]
            signatures = {ev.get("signature", "") for ev in net_lines}
            ports = {ev.get("dest_port") for ev in net_lines}
            tr.check("Network flow/IDS events populated",
                     len(net_lines) > 0,
                     f"{len(net_lines)} events, {len(ports)} destination ports")
            tr.check("Network IDS signatures present",
                     any("SQL injection" in s or "port sweep" in s for s in signatures),
                     f"{len(signatures)} unique signatures")
        except Exception as e:
            tr.check("Network telemetry readable", False, str(e))

    # ── TEST 7: ML model ──────────────────────────────────────────────────
    section("TEST 7 · ML Model (Isolation Forest)")
    model_file = DATA_DIR / "iforest.joblib"
    if model_file.exists():
        try:
            import joblib
            m   = joblib.load(str(model_file))
            ips = list(m["models"].keys())
            tr.check("Model saved to disk", True, f"IPs trained: {ips}")
            for ip in ips[:1]:
                clf = m["models"][ip]
                tr.check(f"IForest [{ip}] has estimators",
                         len(clf.estimators_) > 0,
                         f"{len(clf.estimators_)} trees · "
                         f"{clf.n_features_in_} features")
        except Exception as e:
            tr.check("Model load from disk", False, str(e))
    else:
        tr.advisory("Model not on disk yet (needs 500 events) — in-memory model IS active")
        if corr_db.exists():
            try:
                result = read_duckdb_with_retry(str(corr_db), "SELECT COUNT(*) FROM scored_events")
                if result is not None:
                    scored = result[0][0]
                    tr.check("Correlator scoring in memory",
                             scored > 0, f"{scored} events scored")
                else:
                    tr.check("Correlator scoring check", False, "File locked after retries")
            except Exception as e:
                tr.check("Correlator scoring check", False, str(e))

    # ── TEST 8: Alert generation ──────────────────────────────────────────
    section("TEST 8 · Threat Alert Generation")
    tr.check("correlator.db created", corr_db.exists())
    if corr_db.exists():
        try:
            result = read_duckdb_with_retry(str(corr_db), """
                SELECT threat_class, COUNT(*) n,
                       ROUND(AVG(joint_score),3) avg
                FROM alerts
                GROUP BY threat_class ORDER BY n DESC
            """, fetch_all=True)
            if result is not None:
                alerts_data = result
                total = sum(r[1] for r in alerts_data)
                tr.check("Alerts generated", total > 0, f"{total} total")

                found = {r[0] for r in alerts_data}
                for threat in ["sqli", "privesc", "exfiltration"]:
                    row    = next((r for r in alerts_data if r[0] == threat), None)
                    detail = (f"n={row[1]}, avg_score={row[2]}"
                              if row else "none detected")
                    tr.check(f"'{threat}' threat class detected",
                             threat in found, detail)
            else:
                tr.check("Alert generation", False, "File locked after retries")
        except Exception as e:
            tr.check("Alert generation", False, str(e))

    section("TEST 8B · Cross-Layer Correlation")
    if corr_db.exists():
        try:
            result = read_duckdb_with_retry(str(corr_db), """
                SELECT COUNT(*), ROUND(MAX(network_score), 3), ROUND(MAX(joint_score), 3)
                FROM scored_events WHERE network_score > 0
            """, fetch_all=True)
            if result is not None:
                n, max_net, max_joint = result[0]
                tr.check("DB events correlated with network context",
                         n > 0,
                         f"{n} correlated, max_net={max_net}, max_joint={max_joint}")
            else:
                tr.check("Cross-layer correlation", False, "File locked after retries")
        except Exception as e:
            tr.check("Cross-layer correlation", False, str(e))

    # ── TEST 9: Dashboard ─────────────────────────────────────────────────
    section("TEST 9 · Dashboard HTTP Availability")
    up = port_open(DASH_PORT)
    tr.check("Streamlit on port 8501", up, "http://localhost:8501")
    if up:
        info("Dashboard is live — open http://localhost:8501")

    # ── TEST 10: End-to-end pipeline integrity ────────────────────────────
    section("TEST 10 · End-to-End Pipeline Integrity")
    if proxy_db.exists() and corr_db.exists() and evt_file.exists():
        try:
            events_result = read_duckdb_with_retry(str(proxy_db), "SELECT COUNT(*) FROM db_events")
            alerts_result = read_duckdb_with_retry(str(corr_db), "SELECT COUNT(*) FROM alerts")
            scored_result = read_duckdb_with_retry(str(corr_db), "SELECT COUNT(*) FROM scored_events")

            if events_result is not None and alerts_result is not None and scored_result is not None:
                n_events = events_result[0][0]
                n_alerts = alerts_result[0][0]
                n_scored = scored_result[0][0]

                with open(evt_file) as f:
                    n_queue = sum(1 for _ in f)

                info("Pipeline flow:")
                info(f"  Queries intercepted (proxy)   : {n_events}")
                info(f"  Events published to queue     : {n_queue}")
                info(f"  Events ML-scored (correlator) : {n_scored}")
                info(f"  Alerts generated              : {n_alerts}")
                info(f"  Network events captured       : {sum(1 for _ in open(net_file, encoding='utf-8')) if net_file.exists() else 0}")

                pipeline_ok = (n_events > 0 and n_queue > 0
                               and n_scored > 0 and n_alerts > 0)
                tr.check(
                    "intercept → queue → ML score → alert (all stages active)",
                    pipeline_ok,
                    f"{n_events}→{n_queue}→{n_scored}→{n_alerts}",
                )
            else:
                tr.check("Pipeline integrity", False, "File locked after retries")
        except Exception as e:
            tr.check("Pipeline integrity", False, str(e))
    else:
        missing = [p.name for p in [proxy_db, corr_db, evt_file]
                   if not p.exists()]
        tr.check("Pipeline integrity", False, f"missing files: {missing}")

    return tr


# ══════════════════════════════════════════════════════════════════════════
# BENCHMARK
# ══════════════════════════════════════════════════════════════════════════

def run_eval():
    env = os.environ.copy()
    env["PYTHONPATH"] = str(VENDOR_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    subprocess.run(
        [sys.executable, str(BASE_DIR / "correlator" / "eval.py")],
        env=env,
        check=False,
    )


# ══════════════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════════════

def cmd_demo(hold: bool = True, baseline_count: int = DEFAULT_BASELINE_COUNT):
    header("NetDB-IDS  ·  AUTOMATED DEMO + TEST SUITE", C)
    print(f"  {DIM}Network + Database Intrusion Detection System{X}")
    print(f"  {DIM}Isolation Forest ML · sqlglot AST · 4 attack scenarios · 10 tests{X}\n")

    t0 = time.time()

    section("SETUP")
    pip_install()
    clean_data()

    start_services()
    time.sleep(0.25)

    try:
        webbrowser.open("http://localhost:8501")
        ok("Browser opened → http://localhost:8501")
    except Exception:
        info("Open manually: http://localhost:8501")

    section("PHASE 1  ·  Baseline Traffic  (trains Isolation Forest)")
    step(f"Sending {baseline_count} normal queries to build behavioral model...")
    run_scenario("baseline", "--count", str(baseline_count))
    ok("Baseline complete — ML model trained on normal behavior")

    attacks = [
        ("recon",   "PHASE 2  ·  Reconnaissance     (schema enumeration)"),
        ("sqli",    "PHASE 3  ·  SQL Injection       (UNION, bypass, subquery)"),
        ("privesc", "PHASE 4  ·  Privilege Escalation (DROP, INSERT admin, ALTER)"),
        ("exfil",   "PHASE 5  ·  Data Exfiltration   (SELECT *, PCI data, JOIN)"),
    ]
    for scenario, label in attacks:
        section(label)
        run_scenario(scenario)
        time.sleep(0.1)

    section("CORRELATOR  ·  ML Scoring Pipeline")
    step("Waiting for all events to be scored...")
    wait_for_scoring(timeout=15)

    # Give extra time for file locks to be released
    time.sleep(0.5)

    header("AUTOMATED TEST SUITE  (10 tests)", Y)
    tr     = run_tests()
    passed = tr.summary()

    header("DETECTION BENCHMARK  ·  Precision / Recall / F1", G)
    run_eval()

    elapsed = int(time.time() - t0)
    header("DEMO COMPLETE", G if passed else Y)
    print(f"  ⏱  Total runtime      : {elapsed}s")
    print(f"  🧪 Tests passed       : {G}{B}{len(tr.passed)}/{len(tr.passed)+len(tr.failed)}{X}")
    if tr.failed:
        print(f"  ❌ Tests failed       : {R}{B}{len(tr.failed)}{X}")
    print(f"  🌐 Dashboard          : http://localhost:8501")
    print(f"  📁 Audit DB           : {DATA_DIR / 'proxy.db'}")
    print(f"  📁 Alerts DB          : {DATA_DIR / 'correlator.db'}")
    print(f"  📄 Event queue        : {DATA_DIR / 'events.jsonl'}")
    print()
    if passed:
        print(f"{G}{B}  ✓ All systems nominal. Ready for interview demo.{X}\n")
    else:
        print(f"{Y}  ⚠ Some tests failed — see details above.{X}\n")
    if hold:
        print(f"{DIM}  Services still running. Press Ctrl+C to stop all.{X}\n")
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            stop_all()
    else:
        print(f"{DIM}  Non-holding demo mode: stopping services now.{X}\n")
        stop_all()


def cmd_test():
    header("NetDB-IDS · TEST SUITE", Y)
    tr = run_tests()
    tr.summary()
    sys.exit(0 if not tr.failed else 1)


def cmd_start():
    header("NetDB-IDS · START SERVICES", C)
    pip_install()
    clean_data()
    start_services()
    print(f"\n{G}  ✓ All services running — Dashboard → http://localhost:8501{X}\n")
    print(f"{DIM}  Press Ctrl+C to stop{X}\n")
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        stop_all()


def cmd_attack(baseline_count: int = DEFAULT_BASELINE_COUNT):
    header("NetDB-IDS · ATTACK SCENARIOS", R)
    for s in ["baseline", "recon", "sqli", "privesc", "exfil"]:
        args = ["--count", str(baseline_count)] if s == "baseline" else []
        run_scenario(s, *args)
        time.sleep(0.1)


def cmd_eval():
    header("NetDB-IDS · BENCHMARK REPORT", G)
    run_eval()


def cmd_clean():
    stop_all()
    if DATA_DIR.exists():
        shutil.rmtree(DATA_DIR)
        ok("data/ wiped")
    ok("Clean complete")


# ══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="run.py",
        description="NetDB-IDS — Automated Demo + Test Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
commands:
  demo     Full demo + 10 automated tests   ← START HERE
  demo-once Full demo + tests, then stop services
  test     Run tests only (services must be running)
  start    Start services only
  attack   Run attacks only
  eval     Benchmark report only
  clean    Stop + wipe data
        """,
    )
    parser.add_argument("command",
                        choices=["demo","demo-once","test","start","attack","eval","clean"])
    parser.add_argument("--baseline-count", type=int, default=DEFAULT_BASELINE_COUNT,
                        help=f"Normal baseline queries for demo/attack (default: {DEFAULT_BASELINE_COUNT})")
    args = parser.parse_args()
    {
        "demo":   lambda: cmd_demo(True, args.baseline_count),
        "demo-once": lambda: cmd_demo(False, args.baseline_count),
        "test":   cmd_test,
        "start":  cmd_start,
        "attack": lambda: cmd_attack(args.baseline_count),
        "eval":   cmd_eval,
        "clean":  cmd_clean,
    }[args.command]()
