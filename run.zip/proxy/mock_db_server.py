"""
NetDB-IDS: Mock Database Server (No Docker/PostgreSQL needed)
-------------------------------------------------------------
- SQLite as the backend database (built into Python)
- Listens on TCP port 5433 with a simple line-based SQL protocol
- Parses every query with sqlglot for AST features
- Stores audit events in DuckDB
- Publishes events to an in-process queue (file-based for cross-process)
"""

import asyncio
import json
import os
import sqlite3
import hashlib
import uuid
from datetime import datetime, timezone
from pathlib import Path
import sys

VENDOR_DIR = Path(__file__).parent.parent / "vendor"
if VENDOR_DIR.exists():
    sys.path.insert(0, str(VENDOR_DIR))

import duckdb
import sqlglot
from sqlglot import exp
import structlog

BASE_DIR   = Path(__file__).parent.parent
DATA_DIR   = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

SQLITE_DB  = str(DATA_DIR / "target.db")
DUCKDB_DB  = str(DATA_DIR / "proxy.db")
EVENT_FILE = str(DATA_DIR / "events.jsonl")   # file-based queue
PORT       = int(os.getenv("PROXY_PORT", 5433))

log = structlog.get_logger()

SENSITIVE_TABLES = {"users", "orders", "pg_shadow", "pg_user"}
SQLI_PATTERNS    = ["OR '1'='1", "UNION SELECT", "'; DROP", "--", "OR 1=1"]


# ─── SQLITE SETUP ──────────────────────────────────────────────────────────

def init_sqlite():
    conn = sqlite3.connect(SQLITE_DB, check_same_thread=False)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            role TEXT DEFAULT 'customer',
            credit_card TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            total REAL,
            status TEXT DEFAULT 'pending',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            price REAL,
            stock INTEGER DEFAULT 0,
            category TEXT
        );
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER,
            warehouse TEXT,
            quantity INTEGER,
            updated_at TEXT DEFAULT (datetime('now'))
        );

        INSERT OR IGNORE INTO users (username, password, email, role, credit_card) VALUES
            ('alice',   'hashed_pw_1', 'alice@example.com',   'admin',    '4111-1111-1111-1111'),
            ('bob',     'hashed_pw_2', 'bob@example.com',     'customer', '5500-0000-0000-0004'),
            ('charlie', 'hashed_pw_3', 'charlie@example.com', 'customer', '3400-0000-0000-009'),
            ('diana',   'hashed_pw_4', 'diana@example.com',   'manager',  '6011-0000-0000-0004');

        INSERT OR IGNORE INTO products (name, price, stock, category) VALUES
            ('Laptop Pro 15',      1299.99, 50, 'electronics'),
            ('Wireless Mouse',       29.99, 200,'peripherals'),
            ('USB-C Hub',            49.99, 150,'peripherals'),
            ('Monitor 27"',         399.99, 30, 'electronics'),
            ('Mechanical Keyboard',  89.99, 75, 'peripherals');

        INSERT OR IGNORE INTO orders (user_id, total, status) VALUES
            (2, 1329.98, 'completed'),
            (3,  449.98, 'pending'),
            (4,  139.98, 'shipped');

        INSERT OR IGNORE INTO inventory (product_id, warehouse, quantity) VALUES
            (1,'WH-BERLIN',20),(1,'WH-MUNICH',30),
            (2,'WH-BERLIN',100),(2,'WH-MUNICH',100),
            (3,'WH-BERLIN',75),(4,'WH-MUNICH',30);
    """)
    conn.commit()
    return conn


# ─── FEATURE EXTRACTION ────────────────────────────────────────────────────

def extract_features(sql: str, client_addr: str, session_id: str) -> dict:
    ts         = datetime.now(timezone.utc).isoformat()
    query_hash = hashlib.md5(sql.encode()).hexdigest()[:12]
    sql_upper  = sql.upper()

    f = {
        "timestamp": ts, "client_ip": client_addr,
        "session_id": session_id, "query_hash": query_hash,
        "raw_sql": sql[:2000], "sql_length": len(sql),
        "stmt_type": "UNKNOWN",
        "tables_accessed": [], "sensitive_tables": False, "table_count": 0,
        "has_where": False, "has_union": False, "has_subquery": False,
        "has_wildcard": False, "has_limit": False,
        "join_count": 0, "condition_count": 0,
        "has_privilege_op": False, "has_drop": False,
        "has_comment": "--" in sql or "/*" in sql,
        "sqli_pattern_count": sum(1 for p in SQLI_PATTERNS if p.upper() in sql_upper),
        "heuristic_score": 0.0,
    }

    try:
        parsed = sqlglot.parse_one(sql)
        if parsed:
            f["stmt_type"]      = type(parsed).__name__.upper()
            tables              = [t.name.lower() for t in parsed.find_all(exp.Table)]
            f["tables_accessed"]= tables
            f["table_count"]    = len(tables)
            f["sensitive_tables"] = any(t in SENSITIVE_TABLES for t in tables)
            f["has_where"]      = parsed.find(exp.Where)    is not None
            f["has_union"]      = parsed.find(exp.Union)    is not None
            f["has_subquery"]   = parsed.find(exp.Subquery) is not None
            f["has_limit"]      = parsed.find(exp.Limit)    is not None
            f["join_count"]     = len(list(parsed.find_all(exp.Join)))
            f["has_wildcard"]   = parsed.find(exp.Star)     is not None
            f["has_drop"]       = parsed.find(exp.Drop)     is not None
            priv_nodes = [exp.AlterTable, exp.Drop]
            for name in ("Grant", "Revoke"):
                node = getattr(exp, name, None)
                if node:
                    priv_nodes.append(node)
            f["has_privilege_op"] = any(parsed.find(n) is not None for n in priv_nodes)
    except Exception:
        pass

    if (
        "ALTER TABLE" in sql_upper
        or "DROP TABLE" in sql_upper
        or "ROLE='ADMIN'" in sql_upper.replace(" ", "")
        or '"ROLE"=\'ADMIN\'' in sql_upper.replace(" ", "")
        or "INSERT INTO USERS" in sql_upper and "'ADMIN'" in sql_upper
    ):
        f["has_privilege_op"] = True

    # Heuristic score
    score = 0.0
    if f["sqli_pattern_count"] > 0:                                    score += 0.4
    if f["has_union"]:                                                  score += 0.3
    if f["sensitive_tables"] and f["has_wildcard"] and not f["has_where"]: score += 0.5
    if f["has_privilege_op"]:                                           score += 0.4
    if f["has_drop"]:                                                   score += 0.5
    if f["has_comment"]:                                                score += 0.2
    if f["has_wildcard"] and not f["has_limit"]:                       score += 0.2
    f["heuristic_score"] = min(score, 1.0)
    return f


# ─── DUCKDB AUDIT ──────────────────────────────────────────────────────────

def init_duckdb():
    conn = duckdb.connect(DUCKDB_DB)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS db_events (
            id VARCHAR, timestamp TIMESTAMP, client_ip VARCHAR,
            session_id VARCHAR, query_hash VARCHAR, raw_sql VARCHAR,
            sql_length INTEGER, stmt_type VARCHAR,
            tables_accessed VARCHAR, sensitive_tables BOOLEAN,
            table_count INTEGER, has_where BOOLEAN, has_union BOOLEAN,
            has_subquery BOOLEAN, has_wildcard BOOLEAN, has_limit BOOLEAN,
            join_count INTEGER, condition_count INTEGER,
            has_privilege_op BOOLEAN, has_drop BOOLEAN,
            has_comment BOOLEAN, sqli_pattern_count INTEGER,
            heuristic_score DOUBLE, anomaly_score DOUBLE, threat_class VARCHAR
        )
    """)
    conn.close()


def store_event(f: dict) -> str:
    eid = str(uuid.uuid4())
    conn = duckdb.connect(DUCKDB_DB)
    try:
        conn.execute("""
            INSERT INTO db_events VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,NULL)
        """, [
            eid, f["timestamp"], f["client_ip"], f["session_id"], f["query_hash"],
            f["raw_sql"], f["sql_length"], f["stmt_type"],
            json.dumps(f["tables_accessed"]), f["sensitive_tables"], f["table_count"],
            f["has_where"], f["has_union"], f["has_subquery"], f["has_wildcard"],
            f["has_limit"], f["join_count"], f["condition_count"],
            f["has_privilege_op"], f["has_drop"], f["has_comment"],
            f["sqli_pattern_count"], f["heuristic_score"],
        ])
    finally:
        conn.close()
    return eid


def publish_event(f: dict, event_id: str):
    payload = {**f, "event_id": event_id}
    with open(EVENT_FILE, "a") as fh:
        fh.write(json.dumps(payload, default=str) + "\n")


# ─── SQL EXECUTION ─────────────────────────────────────────────────────────

def execute_sql(sqlite_conn: sqlite3.Connection, sql: str) -> str:
    """Run SQL on SQLite, return result as text."""
    try:
        cur = sqlite_conn.execute(sql)
        if cur.description:
            cols = [d[0] for d in cur.description]
            rows = cur.fetchmany(50)
            lines = [" | ".join(cols)]
            lines += [" | ".join(str(v) for v in row) for row in rows]
            return "\n".join(lines)
        sqlite_conn.commit()
        return f"OK ({cur.rowcount} rows affected)"
    except sqlite3.Error as e:
        return f"ERROR: {e}"


# ─── TCP SERVER ────────────────────────────────────────────────────────────

class MockDBServer:
    def __init__(self):
        init_duckdb()
        self.sqlite     = init_sqlite()   # shared global connection
        self.counter    = 0

    async def handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        addr = writer.get_extra_info("peername")
        client_ip = addr[0] if addr else "unknown"
        self.counter += 1
        session_id = f"sess_{self.counter:06d}"

        writer.write(b"READY\n")
        await writer.drain()

        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                sql = line.decode("utf-8", errors="replace").strip()
                if not sql or sql.upper() == "QUIT":
                    break

                # Feature extraction + audit
                features  = extract_features(sql, client_ip, session_id)
                event_id  = store_event(features)
                publish_event(features, event_id)

                if features["heuristic_score"] >= 0.5:
                    log.warning("HIGH_SCORE", score=features["heuristic_score"],
                                ip=client_ip, sql=sql[:80])

                # Execute and respond
                result = execute_sql(self.sqlite, sql)
                response = (result + "\nEND\n").encode("utf-8")
                writer.write(response)
                await writer.drain()

        except Exception as e:
            log.error("session_error", error=str(e))
        finally:
            writer.close()


async def main():
    structlog.configure(processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(),
    ])

    server_obj = MockDBServer()
    server     = await asyncio.start_server(server_obj.handle, "127.0.0.1", PORT)
    log.info("mock_db_ready", port=PORT, sqlite=SQLITE_DB, duckdb=DUCKDB_DB)

    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
