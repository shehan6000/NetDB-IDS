$ErrorActionPreference = "Stop"

$BundledPython = Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"

if (Test-Path $BundledPython) {
    $env:PYTHONPATH = "$PSScriptRoot\vendor;$env:PYTHONPATH"
    & $BundledPython "$PSScriptRoot\run.py" @args
} else {
    $env:PYTHONPATH = "$PSScriptRoot\vendor;$env:PYTHONPATH"
    & python "$PSScriptRoot\run.py" @args
}
