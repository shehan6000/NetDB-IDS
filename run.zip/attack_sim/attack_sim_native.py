#!/usr/bin/env python3
"""
NetDB-IDS: Native Attack Simulator
------------------------------------
Connects to mock_db_server.py on localhost:5433
Runs 4 attack scenarios + baseline traffic generator.

Usage:
    python attack_sim_native.py --scenario all
    python attack_sim_native.py --scenario baseline
    python attack_sim_native.py --scenario sqli
"""

import argparse
import json
import random
import socket
import time
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

HOST = "127.0.0.1"
PORT = 5433
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
NET_EVENT_FILE = DATA_DIR / "net_events.jsonl"
FAST_DELAY = 0.005

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
RESET  = "\033[0m"

def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_net_event(event: dict):
    DATA_DIR.mkdir(exist_ok=True)
    payload = {
        "id": str(uuid.uuid4()),
        "timestamp": now_utc(),
        "src_ip": event.get("src_ip", HOST),
        "dest_ip": event.get("dest_ip", "127.0.0.1"),
        "dest_port": int(event.get("dest_port", PORT)),
        "proto": event.get("proto", "tcp"),
        "service": event.get("service", "postgres"),
        "event_type": event.get("event_type", "flow"),
        "signature": event.get("signature", ""),
        "severity": float(event.get("severity", 0.0)),
        "bytes_out": int(event.get("bytes_out", 0)),
        "bytes_in": int(event.get("bytes_in", 0)),
        "scenario": event.get("scenario", "unknown"),
        "tool": event.get("tool", "native-simulator"),
    }
    with open(NET_EVENT_FILE, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload) + "\n")


def emit_net_burst(scenario: str, count: int, signature: str, severity: float,
                   ports: list[int] | None = None, bytes_out: int = 500,
                   bytes_in: int = 2500, tool: str = "native-simulator"):
    ports = ports or [PORT]
    for i in range(count):
        write_net_event({
            "scenario": scenario,
            "event_type": "ids_alert" if severity >= 0.5 else "flow",
            "signature": signature,
            "severity": severity,
            "dest_port": ports[i % len(ports)],
            "service": "postgres" if ports[i % len(ports)] == PORT else "unknown",
            "bytes_out": bytes_out + random.randint(0, 300),
            "bytes_in": bytes_in + random.randint(0, 800),
            "tool": tool,
        })
        time.sleep(FAST_DELAY)


def banner(msg, color=CYAN):
    print(f"\n{color}{'─'*55}\n  {msg}\n{'─'*55}{RESET}\n")


class DBClient:
    """Simple TCP client for the mock DB server."""

    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((HOST, PORT))
        self.sock.settimeout(5)
        self.f = self.sock.makefile("rb")
        # Read READY
        self.f.readline()

    def query(self, sql: str, show: bool = True) -> str:
        if show:
            print(f"{YELLOW}[SQL]{RESET} {sql[:90]}")
        self.sock.sendall((sql + "\n").encode("utf-8"))
        lines = []
        while True:
            try:
                line = self.f.readline().decode("utf-8", errors="replace").rstrip("\n")
                if line == "END":
                    break
                lines.append(line)
            except socket.timeout:
                break
        result = "\n".join(lines)
        if show:
            color = RED if result.startswith("ERROR") else GREEN
            print(f"{color}[RES]{RESET} {result[:120]}\n")
        return result

    def close(self):
        try:
            self.sock.sendall(b"QUIT\n")
            self.sock.close()
        except Exception:
            pass


def new_client() -> DBClient:
    """Create a fresh connection (each scenario = fresh session_id)."""
    try:
        return DBClient()
    except ConnectionRefusedError:
        print(f"{RED}[ERR]{RESET} Cannot connect to mock DB on port {PORT}.")
        print("      Make sure mock_db_server.py is running first!")
        print("      Run: python run.py start   (in another terminal)")
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════
# SCENARIO 1: RECONNAISSANCE
# ═══════════════════════════════════════════════════════════════

def scenario_recon():
    banner("SCENARIO 1: RECONNAISSANCE", RED)
    emit_net_burst(
        "recon", 40, "NMAP TCP port sweep against database subnet", 0.70,
        ports=[22, 80, 443, 5432, 5433, 8080, 9200, 9300],
        bytes_out=90, bytes_in=120, tool="nmap-free"
    )
    db = new_client()

    print("Step 1: Schema enumeration")
    recon_queries = [
        "SELECT name FROM sqlite_master WHERE type='table'",
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='users'",
        "SELECT * FROM sqlite_master",
        "SELECT id, username, role FROM users",
        "SELECT count(*) FROM users",
        "SELECT count(*) FROM orders",
    ]
    for q in recon_queries:
        db.query(q)
        time.sleep(FAST_DELAY)

    db.close()
    print(f"{GREEN}[✓] Recon complete — schema inspection queries logged{RESET}")


# ═══════════════════════════════════════════════════════════════
# SCENARIO 2: SQL INJECTION
# ═══════════════════════════════════════════════════════════════

def scenario_sqli():
    banner("SCENARIO 2: SQL INJECTION", RED)
    emit_net_burst(
        "sqli", 8, "ET WEB_SPECIFIC SQL injection attempt UNION SELECT", 0.85,
        ports=[80, 5433], bytes_out=1400, bytes_in=5200, tool="sqlmap-free"
    )
    db = new_client()

    sqli_queries = [
        # Auth bypass
        "SELECT * FROM users WHERE username='admin' OR '1'='1' AND password='x'",
        # UNION extraction
        "SELECT id, username FROM users UNION SELECT 1, sql FROM sqlite_master",
        # Comment bypass
        "SELECT * FROM users WHERE username='admin'-- AND password='wrong'",
        # Subquery extraction
        "SELECT (SELECT credit_card FROM users WHERE username='alice') AS cc",
        # Stacked-style
        "SELECT * FROM users WHERE id=1 OR 1=1",
        # Information gathering
        "SELECT * FROM users UNION SELECT 1,2,3,4,5,6,7",
    ]

    print("Firing SQL injection payloads...")
    for q in sqli_queries:
        db.query(q)
        time.sleep(FAST_DELAY)

    db.close()
    print(f"{GREEN}[✓] SQLi complete — UNION, comment, auth bypass patterns logged{RESET}")


# ═══════════════════════════════════════════════════════════════
# SCENARIO 3: PRIVILEGE ESCALATION
# ═══════════════════════════════════════════════════════════════

def scenario_privesc():
    banner("SCENARIO 3: PRIVILEGE ESCALATION", RED)
    emit_net_burst(
        "privesc", 6, "Suspicious DB admin command sequence over TCP session", 0.75,
        ports=[5433], bytes_out=900, bytes_in=1600, tool="manual-red-team"
    )
    db = new_client()

    priv_queries = [
        # Attempt to read shadow-equivalent
        "SELECT * FROM users WHERE role='admin'",
        # Try to drop a table
        "DROP TABLE IF EXISTS audit_log",
        # Try to create backdoor user
        "INSERT INTO users (username, password, email, role) VALUES ('hacker','pwned','h@x.com','admin')",
        # Try to escalate existing user
        "UPDATE users SET role='admin' WHERE username='bob'",
        # Try to read all passwords
        "SELECT username, password, credit_card FROM users",
        # Attempt to alter schema
        "ALTER TABLE users ADD COLUMN backdoor TEXT",
    ]

    print("Attempting privilege escalation...")
    for q in priv_queries:
        db.query(q)
        time.sleep(FAST_DELAY)

    db.close()
    print(f"{GREEN}[✓] PrivEsc complete — DROP/INSERT admin/ALTER patterns logged{RESET}")


# ═══════════════════════════════════════════════════════════════
# SCENARIO 4: DATA EXFILTRATION
# ═══════════════════════════════════════════════════════════════

def scenario_exfil():
    banner("SCENARIO 4: DATA EXFILTRATION", RED)
    emit_net_burst(
        "exfiltration", 10, "Large outbound transfer from database service", 0.90,
        ports=[5433], bytes_out=800, bytes_in=45000, tool="curl-netcat-free"
    )
    db = new_client()

    exfil_queries = [
        # Full table dumps — no WHERE, no LIMIT
        "SELECT * FROM users",
        "SELECT * FROM orders",
        "SELECT * FROM inventory",
        # Target PCI data specifically
        "SELECT username, email, credit_card FROM users",
        # Cross-table join for complete records
        "SELECT u.username, u.email, u.credit_card, o.total, o.status FROM users u JOIN orders o ON u.id = o.user_id",
        # Everything at once
        "SELECT * FROM users JOIN orders ON users.id = orders.user_id JOIN inventory ON TRUE",
    ]

    print("Dumping sensitive data...")
    for q in exfil_queries:
        db.query(q)
        time.sleep(FAST_DELAY)

    db.close()
    print(f"{GREEN}[✓] Exfil complete — bulk SELECT * + PCI data access logged{RESET}")


# ═══════════════════════════════════════════════════════════════
# BASELINE TRAFFIC
# ═══════════════════════════════════════════════════════════════

def generate_baseline(n: int = 120):
    banner("GENERATING BASELINE TRAFFIC", GREEN)
    print(f"Sending {n} legitimate queries to train ML model...\n")
    emit_net_burst(
        "baseline", 20, "Normal application traffic to database service", 0.05,
        ports=[5433], bytes_out=350, bytes_in=1300, tool="app-client"
    )

    normal = [
        "SELECT id, name, price FROM products WHERE category = 'electronics'",
        "SELECT id, status, total FROM orders WHERE user_id = 2",
        "SELECT p.name, i.quantity FROM products p JOIN inventory i ON p.id = i.product_id WHERE i.warehouse = 'WH-BERLIN'",
        "SELECT COUNT(*) FROM orders WHERE status = 'pending'",
        "SELECT SUM(total) FROM orders WHERE status = 'completed'",
        "SELECT * FROM products WHERE price < 100 LIMIT 10",
        "SELECT id, username FROM users WHERE role = 'customer' LIMIT 5",
        "SELECT name, price FROM products WHERE stock > 0 ORDER BY price LIMIT 20",
        "SELECT warehouse, SUM(quantity) FROM inventory GROUP BY warehouse",
        "SELECT COUNT(*) FROM users WHERE role = 'customer'",
    ]

    db = new_client()
    for i in range(n):
        db.query(random.choice(normal), show=(i < 3))
        if i == 3:
            print("  [... sending silently ...]")
        if i % 50 == 0 and i > 0:
            print(f"  Progress: {i}/{n} queries sent")
        time.sleep(FAST_DELAY)

    db.close()
    print(f"\n{GREEN}[✓] Baseline complete — model ready for anomaly detection{RESET}")


# ─── MAIN ──────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="NetDB-IDS Attack Simulator (Native)")
    parser.add_argument("--scenario",
                        choices=["recon", "sqli", "privesc", "exfil", "all", "baseline"],
                        default="all")
    parser.add_argument("--delay", type=float, default=0.1)
    parser.add_argument("--count", type=int, default=120,
                        help="Number of normal baseline queries to generate")
    args = parser.parse_args()

    if args.scenario == "all":
        print(f"\n{RED}{'═'*55}")
        print("  NetDB-IDS FULL ATTACK SUITE (Native Mode)")
        print(f"{'═'*55}{RESET}")
        generate_baseline(args.count)
        time.sleep(args.delay)
        for fn in [scenario_recon, scenario_sqli, scenario_privesc, scenario_exfil]:
            fn()
            time.sleep(args.delay)
    elif args.scenario == "baseline":
        generate_baseline(args.count)
    elif args.scenario == "recon":
        scenario_recon()
    elif args.scenario == "sqli":
        scenario_sqli()
    elif args.scenario == "privesc":
        scenario_privesc()
    elif args.scenario == "exfil":
        scenario_exfil()
