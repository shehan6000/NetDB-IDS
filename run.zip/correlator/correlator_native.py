"""
NetDB-IDS: Native Correlator (No Docker/Redis needed)
------------------------------------------------------
Reads events from data/events.jsonl (written by mock_db_server)
Runs Isolation Forest, writes alerts to data/correlator.db
"""

import json
import os
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import sys

VENDOR_DIR = Path(__file__).parent.parent / "vendor"
if VENDOR_DIR.exists():
    sys.path.insert(0, str(VENDOR_DIR))

import duckdb
import numpy as np
import structlog
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import joblib

BASE_DIR   = Path(__file__).parent.parent
DATA_DIR   = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

EVENT_FILE    = str(DATA_DIR / "events.jsonl")
NET_EVENT_FILE = str(DATA_DIR / "net_events.jsonl")
DUCKDB_DB     = str(DATA_DIR / "correlator.db")
MODEL_FILE    = str(DATA_DIR / "iforest.joblib")
ALERT_THRESHOLD = float(os.getenv("ALERT_THRESHOLD", "0.55"))
MIN_TRAIN     = 40
TRAIN_EVERY   = 40

log = structlog.get_logger()

FEATURE_COLS = [
    "sql_length", "table_count", "sensitive_tables", "has_where",
    "has_union", "has_subquery", "has_wildcard", "has_limit",
    "join_count", "condition_count", "has_privilege_op", "has_drop",
    "has_comment", "sqli_pattern_count", "heuristic_score",
]

def to_vec(e: dict) -> np.ndarray:
    return np.array([
        float(e.get("sql_length", 0)),
        float(e.get("table_count", 0)),
        1.0 if e.get("sensitive_tables") else 0.0,
        1.0 if e.get("has_where") else 0.0,
        1.0 if e.get("has_union") else 0.0,
        1.0 if e.get("has_subquery") else 0.0,
        1.0 if e.get("has_wildcard") else 0.0,
        1.0 if e.get("has_limit") else 0.0,
        float(e.get("join_count", 0)),
        float(e.get("condition_count", 0)),
        1.0 if e.get("has_privilege_op") else 0.0,
        1.0 if e.get("has_drop") else 0.0,
        1.0 if e.get("has_comment") else 0.0,
        float(e.get("sqli_pattern_count", 0)),
        float(e.get("heuristic_score", 0.0)),
    ], dtype=np.float32)


def classify(e: dict) -> str:
    raw = str(e.get("raw_sql", "")).upper().replace(" ", "")
    if (
        "ALTERTABLE" in raw or "DROPTABLE" in raw
        or "ROLE='ADMIN'" in raw
        or "INSERTINTOUSERS" in raw and "'ADMIN'" in raw
    ):
        return "privesc"
    if e.get("has_privilege_op") or e.get("has_drop"):      return "privesc"
    if e.get("has_union") or e.get("sqli_pattern_count", 0) > 0: return "sqli"
    if e.get("has_wildcard") and not e.get("has_limit") and e.get("sensitive_tables"):
        return "exfiltration"
    if e.get("stmt_type") == "SELECT" and e.get("table_count", 0) == 0:
        return "recon"
    return "anomaly"


def parse_ts(value: str) -> float:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except Exception:
        return time.time()


class NetworkContext:
    """Tiny Zeek/Suricata-style context store for cross-layer correlation."""

    def __init__(self, window_sec: int = 90):
        self.window_sec = window_sec
        self.events = []
        self.file_pos = 0

    def poll(self):
        if not os.path.exists(NET_EVENT_FILE):
            return
        with open(NET_EVENT_FILE, "r", encoding="utf-8") as fh:
            fh.seek(self.file_pos)
            lines = fh.readlines()
            self.file_pos = fh.tell()
        for line in lines:
            try:
                ev = json.loads(line)
                ev["_ts"] = parse_ts(ev.get("timestamp"))
                self.events.append(ev)
            except json.JSONDecodeError:
                continue
        cutoff = time.time() - (self.window_sec * 6)
        self.events = [ev for ev in self.events if ev.get("_ts", 0) >= cutoff]

    def score_for(self, db_event: dict) -> tuple[float, str, str]:
        self.poll()
        db_ts = parse_ts(db_event.get("timestamp"))
        src_ip = db_event.get("client_ip", "")
        nearby = [
            ev for ev in self.events
            if ev.get("src_ip") == src_ip and abs(ev.get("_ts", 0) - db_ts) <= self.window_sec
        ]
        if not nearby:
            return 0.0, "none", "[]"

        max_severity = max(float(ev.get("severity", 0.0)) for ev in nearby)
        unique_ports = len({int(ev.get("dest_port", 0)) for ev in nearby})
        bytes_in = sum(int(ev.get("bytes_in", 0)) for ev in nearby)
        signatures = [ev.get("signature", "") for ev in nearby if ev.get("signature")]

        score = max_severity
        if unique_ports >= 6:
            score = max(score, 0.70)
        if bytes_in >= 100000:
            score = max(score, 0.90)

        context_type = "network-anomaly"
        joined = " ".join(signatures).lower()
        if "port sweep" in joined or unique_ports >= 6:
            context_type = "recon"
        elif "sql injection" in joined or "union select" in joined:
            context_type = "sqli"
        elif "admin command" in joined:
            context_type = "privesc"
        elif "large outbound" in joined or bytes_in >= 100000:
            context_type = "exfiltration"

        compact = [
            {
                "timestamp": ev.get("timestamp"),
                "dest_port": ev.get("dest_port"),
                "signature": ev.get("signature"),
                "severity": ev.get("severity"),
                "bytes_in": ev.get("bytes_in"),
                "tool": ev.get("tool"),
            }
            for ev in nearby[-8:]
        ]
        return float(min(score, 1.0)), context_type, json.dumps(compact)


def init_duckdb():
    conn = duckdb.connect(DUCKDB_DB)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id VARCHAR, timestamp TIMESTAMP, client_ip VARCHAR,
            joint_score DOUBLE, threat_class VARCHAR,
            db_event_id VARCHAR, raw_sql VARCHAR,
            db_score DOUBLE, network_score DOUBLE, network_context VARCHAR,
            acknowledged BOOLEAN DEFAULT FALSE
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scored_events (
            event_id VARCHAR, anomaly_score DOUBLE, threat_class VARCHAR,
            timestamp TIMESTAMP, network_score DOUBLE, joint_score DOUBLE
        )
    """)
    conn.close()


class IFModel:
    def __init__(self):
        self.models  = {}
        self.scalers = {}
        self.buffers = defaultdict(list)
        self.count   = 0

    def score(self, e: dict) -> float:
        ip  = e.get("client_ip", "unknown")
        vec = to_vec(e)
        self.buffers[ip].append(vec)
        self.count += 1

        if len(self.buffers[ip]) >= MIN_TRAIN and len(self.buffers[ip]) % TRAIN_EVERY == 0:
            self._train(ip)

        return self._predict(ip, vec)

    def _train(self, ip: str):
        X = np.vstack(self.buffers[ip])
        sc = StandardScaler().fit(X)
        clf = IsolationForest(n_estimators=100, contamination=0.08,
                              random_state=42).fit(sc.transform(X))
        self.scalers[ip] = sc
        self.models[ip]  = clf
        log.info("model_trained", ip=ip, n=len(self.buffers[ip]))

    def _predict(self, ip: str, vec: np.ndarray) -> float:
        if ip not in self.models:
            return float(vec[-1])   # heuristic_score fallback
        X = self.scalers[ip].transform(vec.reshape(1, -1))
        raw = self.models[ip].decision_function(X)[0]
        return float(np.clip(1.0 / (1.0 + np.exp(5 * raw)), 0, 1))


def main():
    structlog.configure(processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(),
    ])
    log.info("correlator_starting", event_file=EVENT_FILE)

    init_duckdb()
    model = IFModel()
    net_context = NetworkContext()

    # Try loading saved model
    if os.path.exists(MODEL_FILE):
        try:
            saved = joblib.load(MODEL_FILE)
            model.models  = saved["models"]
            model.scalers = saved["scalers"]
            log.info("model_loaded")
        except Exception:
            pass

    file_pos = 0
    # Fast-forward to end of existing file (don't reprocess old events)
    if os.path.exists(EVENT_FILE):
        with open(EVENT_FILE, "r") as f:
            f.seek(0, 2)
            file_pos = f.tell()

    log.info("correlator_ready", threshold=ALERT_THRESHOLD)

    save_counter = 0

    while True:
        try:
            if not os.path.exists(EVENT_FILE):
                time.sleep(0.1)
                continue

            with open(EVENT_FILE, "r") as f:
                f.seek(file_pos)
                new_lines = f.readlines()
                file_pos  = f.tell()

            scored_rows = []
            alert_rows = []
            for line in new_lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except json.JSONDecodeError:
                    continue

                db_score = model.score(ev)
                net_score, net_class, net_json = net_context.score_for(ev)
                score = 1 - ((1 - db_score) * (1 - net_score))
                db_threat = classify(ev)
                if db_threat != "anomaly" and float(ev.get("heuristic_score", 0.0)) > 0:
                    threat = db_threat
                else:
                    threat = classify(ev) if db_score >= ALERT_THRESHOLD else net_class
                if score < ALERT_THRESHOLD:
                    threat = None

                scored_rows.append(
                    [
                        ev.get("event_id",""), db_score, threat,
                        ev.get("timestamp", datetime.now(timezone.utc).isoformat()),
                        net_score, score,
                    ]
                )

                if score >= ALERT_THRESHOLD:
                    alert_id = str(uuid.uuid4())
                    alert_rows.append(
                        [
                            alert_id, ev.get("timestamp"), ev.get("client_ip",""),
                            round(score, 4), threat, ev.get("event_id",""),
                            ev.get("raw_sql","")[:500], round(db_score, 4),
                            round(net_score, 4), net_json,
                        ]
                    )
                    log.warning("ALERT", id=alert_id[:8],
                                ip=ev.get("client_ip",""),
                                score=round(score, 3), db=round(db_score, 3),
                                net=round(net_score, 3), threat=threat,
                                sql=ev.get("raw_sql","")[:60])

                save_counter += 1
                if save_counter % 500 == 0:
                    joblib.dump({"models": model.models, "scalers": model.scalers},
                                MODEL_FILE)

            if scored_rows or alert_rows:
                conn = duckdb.connect(DUCKDB_DB)
                try:
                    if scored_rows:
                        conn.executemany(
                            "INSERT INTO scored_events VALUES (?,?,?,?,?,?)",
                            scored_rows,
                        )
                    if alert_rows:
                        conn.executemany(
                            "INSERT INTO alerts VALUES (?,?,?,?,?,?,?,?,?,?,FALSE)",
                            alert_rows,
                        )
                finally:
                    conn.close()

            if not new_lines:
                time.sleep(0.05)

        except Exception as e:
            log.error("correlator_error", error=str(e))
            time.sleep(0.2)


if __name__ == "__main__":
    main()
