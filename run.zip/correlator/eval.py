#!/usr/bin/env python3
"""
NetDB-IDS: Evaluation Report (Native Mode)
"""
import json
import time
from pathlib import Path
from datetime import datetime, timezone
import sys

VENDOR_DIR = Path(__file__).parent.parent / "vendor"
if VENDOR_DIR.exists():
    sys.path.insert(0, str(VENDOR_DIR))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import duckdb
import numpy as np

BASE_DIR     = Path(__file__).parent.parent
DATA_DIR     = BASE_DIR / "data"
PROXY_DB     = str(DATA_DIR / "proxy.db")
CORRELATOR_DB= str(DATA_DIR / "correlator.db")

def read_db_with_retry(db_path, query, max_retries=5, delay=0.5):
    """Read from DuckDB with retry logic for Windows file locking."""
    for attempt in range(max_retries):
        try:
            conn = duckdb.connect(db_path, read_only=True)
            result = conn.execute(query).fetchall()
            conn.close()
            return result
        except Exception as e:
            if "already open" in str(e) and attempt < max_retries - 1:
                time.sleep(delay)
                continue
            raise e
    return []

def read_df_with_retry(db_path, query, max_retries=5, delay=0.5):
    """Read DataFrame from DuckDB with retry logic."""
    for attempt in range(max_retries):
        try:
            conn = duckdb.connect(db_path, read_only=True)
            df = conn.execute(query).df()
            conn.close()
            return df
        except Exception as e:
            if "already open" in str(e) and attempt < max_retries - 1:
                time.sleep(delay)
                continue
            raise e
    return None

def main():
    # Load events with retry
    try:
        events = read_df_with_retry(PROXY_DB, "SELECT * FROM db_events")
        if events is None:
            print("Cannot read events: File locked after retries")
            print("Tip: Wait a moment and run 'python run.py eval' again")
            return
    except Exception as e:
        print(f"Cannot read events: {e}")
        print("Tip: Wait a moment and run 'python run.py eval' again")
        return

    # Load alerts with retry
    try:
        alerts = read_df_with_retry(CORRELATOR_DB, "SELECT * FROM alerts")
        scored = read_df_with_retry(CORRELATOR_DB, "SELECT * FROM scored_events")
        if alerts is None or scored is None:
            print("Cannot read alerts: File locked after retries")
            return
    except Exception as e:
        print(f"Cannot read alerts: {e}")
        return

    print("\n" + "═"*60)
    print("  NetDB-IDS DETECTION PERFORMANCE REPORT")
    print("═"*60)
    print(f"  Total DB Events : {len(events)}")
    print(f"  Total Alerts    : {len(alerts)}")
    print(f"  Total Scored    : {len(scored)}")
    print("─"*60)

    scenarios = {
        "sqli":        lambda e: (e["has_union"]==True) | (e["sqli_pattern_count"]>0),
        "privesc":     lambda e: (e["has_privilege_op"]==True) | (e["has_drop"]==True),
        "exfiltration":lambda e: (e["has_wildcard"]==True) & (e["sensitive_tables"]==True),
        "recon":       lambda e: (e["stmt_type"]=="SELECT") & (e["table_count"]==0),
    }

    print(f"  {'Type':<16} {'P':>6} {'R':>6} {'F1':>6} {'TP':>5} {'FP':>5} {'FN':>5}")
    print("─"*60)

    for attack, gt_fn in scenarios.items():
        try:
            gt_mask   = gt_fn(events)
            gt_ids    = set(events[gt_mask]["id"].tolist())
            det_ids   = set(alerts[alerts["threat_class"]==attack]["db_event_id"].tolist())

            TP = len(gt_ids & det_ids)
            FP = len(det_ids - gt_ids)
            FN = len(gt_ids - det_ids)

            P  = TP/(TP+FP) if TP+FP > 0 else 0.0
            R  = TP/(TP+FN) if TP+FN > 0 else 0.0
            F1 = 2*P*R/(P+R) if P+R > 0 else 0.0

            print(f"  {attack:<16} {P:>6.3f} {R:>6.3f} {F1:>6.3f} {TP:>5} {FP:>5} {FN:>5}")
        except Exception as e:
            print(f"  {attack:<16} ERROR: {e}")

    print("─"*60)

    # Latency (heuristic: use heuristic_score as proxy since we don't have real timestamps paired)
    if not alerts.empty:
        scores = alerts["joint_score"].dropna()
        print(f"  Alert Score  — Mean: {scores.mean():.3f}  Max: {scores.max():.3f}  Min: {scores.min():.3f}")

    print("═"*60)
    print(f"\n  Generated: {datetime.now(timezone.utc).isoformat()}\n")

if __name__ == "__main__":
    main()
